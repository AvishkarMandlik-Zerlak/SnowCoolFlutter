import 'package:flutter/material.dart'; // Core Flutter library for building UIs.
import 'package:snow_trading_cool/dev_utils.dart';
import 'package:snow_trading_cool/utils/constants.dart';
import 'screens/login_screen.dart'; // Import the login screen for navigation.

void main() {
  // This function runs the app and initializes the MaterialApp.
  DevUtils.createDemoAdmin();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  // Constructor for MyApp - A stateless widget that doesn't change state.
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Build method - Returns the root widget of the app.
    return MaterialApp(
      title:
          'Snowcool Inventory', // Title of the app shown in the task switcher.
      theme: ThemeData(
        // App-wide theme - Sets colors, fonts, etc. for consistency.
        primarySwatch: Colors.blue, // Primary color scheme based on blue.
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.accentBlue,
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
          actionsIconTheme: IconThemeData(
            color: Colors.white,
          ),
        )
      ),
      home:
          const LoginScreen(), // Sets LoginScreen as the initial route/home page.
      debugShowCheckedModeBanner:
          false, // Hides the debug banner in development mode.
    );
  }
}
